﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmacy
{
    public partial class Form2 : Form
    {
        string connectionString = "Data Source=(localdb)\\Local;Initial Catalog=Pharmacy;Integrated Security=True";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            gunaDataGridView1.Hide();
        }

        private void gunaGradientButton3_Click(object sender, EventArgs e)
        {
            gunaDataGridView1.Show();
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlDataAdapter sdata = new SqlDataAdapter("select * from medcine", scon);
                DataTable dt1 = new DataTable();
                sdata.Fill(dt1);
                gunaDataGridView1.DataSource = dt1;
            }
        }

        private void gunaGradientButton1_Click(object sender, EventArgs e)
        {
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                SqlDataAdapter sdata = new SqlDataAdapter("insert into medcine(medID,medName,manfact,exp,quantity,price) values('" + gunaLineTextBox1.Text + "','" + gunaLineTextBox2.Text + "','" + gunaDateTimePicker1.Text + "','" + gunaDateTimePicker2.Text + "','" + gunaNumeric1.Value + "','" + gunaLineTextBox3.Text+"')", scon);
                DataTable dt1 = new DataTable();
                sdata.Fill(dt1);
                MessageBox.Show("Entry Successfull");
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
