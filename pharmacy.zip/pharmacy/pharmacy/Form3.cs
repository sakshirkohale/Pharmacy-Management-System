﻿using Guna.UI.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmacy
{
    public partial class Form3 : Form
    {
        string connectionString = "Data Source=(localdb)\\Local;Initial Catalog=Pharmacy;Integrated Security=True";
        public Form3()
        {
            InitializeComponent();
        }

        private void gunaGradientButton1_Click(object sender, EventArgs e)
        {
            using (SqlConnection scon2 = new SqlConnection(connectionString))
            {
                SqlDataAdapter sdata1 = new SqlDataAdapter("delete medcine where medID="+gunaTextBox1.Text, scon2);
                DataTable dt11 = new DataTable();
                sdata1.Fill(dt11);
                SqlDataAdapter sdata2 = new SqlDataAdapter("select * from medcine where exp<=GetDate()", scon2);
                DataTable dt1 = new DataTable();
                sdata2.Fill(dt1);
                gunaTextBox1.Clear();
                gunaDataGridView1.DataSource = dt1;
            }
        }
        public void showexp()
        {
            
            using (SqlConnection scon1 = new SqlConnection(connectionString))
            {
                SqlDataAdapter sdata1 = new SqlDataAdapter("select * from medcine where exp<=GetDate()", scon1);
                DataTable dt11 = new DataTable();
                sdata1.Fill(dt11);
                gunaDataGridView1.DataSource = dt11;
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            showexp();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            showexp();
        }
    }
}
