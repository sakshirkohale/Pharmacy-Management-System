﻿using Guna.UI.WinForms;
using pharmacy.PharmacyDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pharmacy
{
    public partial class Form1 : Form
    {
        string connectionString = "Data Source=(localdb)\\local;Initial Catalog=Pharmacy;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
        }

        private void gunaGradientButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void gunaGradientButton2_Click(object sender, EventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gunaPanel2.Hide();
            gunaPanel3.Hide();
            gunaPanel4.Hide();
            gunaPanel4.Show();
            panel1.Show();
            panel2.Hide();
            gunaPanel1.Hide();
        }

        private void gunaGradientButton3_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void gunaPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gunaGradientButton4_Click(object sender, EventArgs e)
        {
            
        }

        private void gunaPanel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gunaAdvenceTileButton1_Click(object sender, EventArgs e)
        {
            gunaAdvenceTileButton3.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton1.LineColor = Color.Transparent;
            gunaAdvenceTileButton2.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton5.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton4.LineColor = Color.FromArgb(255, 206, 143);
            gunaPanel2.Show();
            gunaPanel3.Hide();
            gunaPanel4.Hide(); gunaPanel1.Hide();
            Form2 f2 = new Form2() { TopLevel = false, TopMost = true };
            f2.FormBorderStyle = FormBorderStyle.None;
            gunaPanel2.Controls.Add(f2);
            f2.Show();
        }

        private void gunaAdvenceTileButton2_Click(object sender, EventArgs e)
        { 
            gunaAdvenceTileButton3.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton1.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton2.LineColor = Color.Transparent;
            gunaAdvenceTileButton5.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton4.LineColor = Color.FromArgb(255, 206, 143);
            gunaPanel2.Hide();
            gunaPanel3.Show(); gunaPanel1.Hide();
            gunaPanel4.Hide();
            Form3 f3 = new Form3() { TopLevel = false, TopMost = true };
            f3.FormBorderStyle = FormBorderStyle.None;
            gunaPanel3.Controls.Add(f3);
            f3.Show();
        }

        private void gunaAdvenceTileButton3_Click(object sender, EventArgs e)
        {
            gunaAdvenceTileButton3.LineColor= Color.Transparent;
            gunaAdvenceTileButton1.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton2.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton5.LineColor = Color.FromArgb(255, 206, 143); 
            gunaAdvenceTileButton4.LineColor = Color.FromArgb(255, 206, 143);
            gunaPanel2.Hide(); gunaPanel4.Show();
            gunaPanel3.Hide(); gunaPanel1.Hide();
            Form4 f4 = new Form4() { TopLevel = false, TopMost = true };
            f4.FormBorderStyle = FormBorderStyle.None;
            gunaPanel4.Controls.Add(f4);
            f4.Show();
        }

        private void gunaAdvenceTileButton4_Click(object sender, EventArgs e)
        {
            gunaAdvenceTileButton3.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton1.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton2.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton5.LineColor = Color.FromArgb(255, 206, 143);
            gunaAdvenceTileButton4.LineColor = Color.Transparent;
            gunaPanel2.Hide(); gunaPanel4.Hide();
            gunaPanel3.Hide(); gunaPanel1.Show();
            Form5 f5 = new Form5() { TopLevel = false, TopMost = true };
            f5.FormBorderStyle = FormBorderStyle.None;
            gunaPanel1.Controls.Add(f5);
            f5.Show();
        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection scon2 = new SqlConnection(connectionString))
                {
                    scon2.Open();
                    SqlDataAdapter scomm2 = new SqlDataAdapter("insert into staff(name,Id,password) values('" + gunaTextBox5.Text + "','" + gunaTextBox3.Text + "','" + gunaTextBox4.Text+"')", scon2);
                    DataTable dt1 = new DataTable();
                    scomm2.Fill(dt1);
                }
                panel2.Hide(); panel1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fill the boxes");
            }
        }
        
        private void label6_Click(object sender, EventArgs e)
        {
            panel2.Show();
            panel1.Hide(); 
        }

        private void gunaTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public static string Log_InNAME;
        public static int t = 0;

        
        void createlogin()
        {
            gunaPanel5.Hide();

        }
        PharmacyDataSet ph = new PharmacyDataSet();
        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            //if (gunaTextBox1.Text.Equals("0044") || gunaTextBox1.Text.Equals("0055"))
            //{

            //    if (gunaTextBox2.Text.Equals("nobita") || gunaTextBox2.Text.Equals("doramon"))
            //    {
            //        gunaPanel5.Hide();
            //    }
            //    else {
            //        MessageBox.Show("Password or Id Is Incorrect");
            //    }
            //}
            string password = "";
            string ID = "";
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scomm = new SqlCommand("select Id,password from staff where Id='"+gunaTextBox1.Text+"'",scon);
                SqlDataReader sdata = scomm.ExecuteReader();
                while (sdata.Read())
                {
                    password = sdata.GetValue(1).ToString();
                    ID= sdata.GetValue(0).ToString();
                }
                if (password == gunaTextBox2.Text && ID == gunaTextBox1.Text)
                {
                    gunaPanel5.Hide();
                }
                else
                {
                    MessageBox.Show("Password or Id Is Incorrect");
                }
            }
            
        }

        private void gunaAdvenceTileButton5_Click(object sender, EventArgs e)
        {
            gunaTextBox1.Clear();
            gunaTextBox2.Clear();
            gunaPanel5.Show();
        }

        private void gunaPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gunaPanel5_Paint_1(object sender, PaintEventArgs e)
        {

        }
    }
}
