﻿namespace pharmacy
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.gunaGradientButton2 = new Guna.UI.WinForms.GunaGradientButton();
            this.gunaGradientButton1 = new Guna.UI.WinForms.GunaGradientButton();
            this.gunaTextBox1 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox2 = new Guna.UI.WinForms.GunaTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.gunaTextBox3 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox4 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox5 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox6 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox7 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox8 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox9 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox10 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox11 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox12 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox13 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox14 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox15 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox16 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox17 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox18 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox19 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox20 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox21 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox22 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox23 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox24 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox33 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox34 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox35 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox36 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox37 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox38 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox39 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox40 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaTextBox25 = new Guna.UI.WinForms.GunaTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.gunaLineTextBox1 = new Guna.UI.WinForms.GunaLineTextBox();
            this.SuspendLayout();
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(583, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Price/Unit";
            // 
            // gunaGradientButton2
            // 
            this.gunaGradientButton2.AnimationHoverSpeed = 0.07F;
            this.gunaGradientButton2.AnimationSpeed = 0.03F;
            this.gunaGradientButton2.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(134)))), ((int)(((byte)(5)))));
            this.gunaGradientButton2.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(134)))), ((int)(((byte)(5)))));
            this.gunaGradientButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaGradientButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaGradientButton2.ForeColor = System.Drawing.Color.White;
            this.gunaGradientButton2.Image = null;
            this.gunaGradientButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaGradientButton2.Location = new System.Drawing.Point(383, 379);
            this.gunaGradientButton2.Name = "gunaGradientButton2";
            this.gunaGradientButton2.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(98)))), ((int)(((byte)(13)))));
            this.gunaGradientButton2.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(98)))), ((int)(((byte)(13)))));
            this.gunaGradientButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaGradientButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientButton2.OnHoverImage = null;
            this.gunaGradientButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientButton2.Size = new System.Drawing.Size(157, 29);
            this.gunaGradientButton2.TabIndex = 5;
            this.gunaGradientButton2.Text = "TOTAL";
            this.gunaGradientButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaGradientButton2.Click += new System.EventHandler(this.gunaGradientButton2_Click);
            // 
            // gunaGradientButton1
            // 
            this.gunaGradientButton1.AnimationHoverSpeed = 0.07F;
            this.gunaGradientButton1.AnimationSpeed = 0.03F;
            this.gunaGradientButton1.BaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(134)))), ((int)(((byte)(5)))));
            this.gunaGradientButton1.BaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(134)))), ((int)(((byte)(5)))));
            this.gunaGradientButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaGradientButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaGradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaGradientButton1.ForeColor = System.Drawing.Color.White;
            this.gunaGradientButton1.Image = null;
            this.gunaGradientButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaGradientButton1.Location = new System.Drawing.Point(217, 378);
            this.gunaGradientButton1.Name = "gunaGradientButton1";
            this.gunaGradientButton1.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(98)))), ((int)(((byte)(13)))));
            this.gunaGradientButton1.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(98)))), ((int)(((byte)(13)))));
            this.gunaGradientButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaGradientButton1.OnHoverImage = null;
            this.gunaGradientButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaGradientButton1.Size = new System.Drawing.Size(160, 30);
            this.gunaGradientButton1.TabIndex = 0;
            this.gunaGradientButton1.Text = "Print";
            this.gunaGradientButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaGradientButton1.Click += new System.EventHandler(this.gunaGradientButton1_Click);
            // 
            // gunaTextBox1
            // 
            this.gunaTextBox1.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox1.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox1.BorderSize = 0;
            this.gunaTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox1.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox1.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox1.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox1.Location = new System.Drawing.Point(61, 114);
            this.gunaTextBox1.Name = "gunaTextBox1";
            this.gunaTextBox1.PasswordChar = '\0';
            this.gunaTextBox1.SelectedText = "";
            this.gunaTextBox1.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox1.TabIndex = 7;
            this.gunaTextBox1.TextChanged += new System.EventHandler(this.gunaTextBox1_TextChanged);
            // 
            // gunaTextBox2
            // 
            this.gunaTextBox2.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox2.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox2.BorderSize = 0;
            this.gunaTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox2.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox2.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox2.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox2.Location = new System.Drawing.Point(222, 114);
            this.gunaTextBox2.Margin = new System.Windows.Forms.Padding(2);
            this.gunaTextBox2.Name = "gunaTextBox2";
            this.gunaTextBox2.PasswordChar = '\0';
            this.gunaTextBox2.SelectedText = "";
            this.gunaTextBox2.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox2.TabIndex = 8;
            this.gunaTextBox2.TextChanged += new System.EventHandler(this.gunaTextBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(104, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Medicine ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(273, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Name";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(417, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Items";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // gunaTextBox3
            // 
            this.gunaTextBox3.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox3.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox3.BorderSize = 0;
            this.gunaTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox3.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox3.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox3.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox3.Location = new System.Drawing.Point(383, 114);
            this.gunaTextBox3.Name = "gunaTextBox3";
            this.gunaTextBox3.PasswordChar = '\0';
            this.gunaTextBox3.SelectedText = "";
            this.gunaTextBox3.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox3.TabIndex = 11;
            this.gunaTextBox3.TextChanged += new System.EventHandler(this.gunaTextBox3_TextChanged);
            // 
            // gunaTextBox4
            // 
            this.gunaTextBox4.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox4.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox4.BorderSize = 0;
            this.gunaTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox4.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox4.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox4.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox4.Location = new System.Drawing.Point(545, 114);
            this.gunaTextBox4.Name = "gunaTextBox4";
            this.gunaTextBox4.PasswordChar = '\0';
            this.gunaTextBox4.SelectedText = "";
            this.gunaTextBox4.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox4.TabIndex = 13;
            this.gunaTextBox4.Text = "0";
            this.gunaTextBox4.TextChanged += new System.EventHandler(this.gunaTextBox4_TextChanged);
            // 
            // gunaTextBox5
            // 
            this.gunaTextBox5.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox5.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox5.BorderSize = 0;
            this.gunaTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox5.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox5.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox5.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox5.Location = new System.Drawing.Point(545, 145);
            this.gunaTextBox5.Name = "gunaTextBox5";
            this.gunaTextBox5.PasswordChar = '\0';
            this.gunaTextBox5.SelectedText = "";
            this.gunaTextBox5.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox5.TabIndex = 17;
            this.gunaTextBox5.Text = "0";
            this.gunaTextBox5.TextChanged += new System.EventHandler(this.gunaTextBox5_TextChanged);
            // 
            // gunaTextBox6
            // 
            this.gunaTextBox6.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox6.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox6.BorderSize = 0;
            this.gunaTextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox6.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox6.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox6.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox6.Location = new System.Drawing.Point(383, 145);
            this.gunaTextBox6.Name = "gunaTextBox6";
            this.gunaTextBox6.PasswordChar = '\0';
            this.gunaTextBox6.SelectedText = "";
            this.gunaTextBox6.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox6.TabIndex = 16;
            this.gunaTextBox6.TextChanged += new System.EventHandler(this.gunaTextBox6_TextChanged);
            // 
            // gunaTextBox7
            // 
            this.gunaTextBox7.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox7.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox7.BorderSize = 0;
            this.gunaTextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox7.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox7.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox7.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox7.Location = new System.Drawing.Point(222, 145);
            this.gunaTextBox7.Margin = new System.Windows.Forms.Padding(2);
            this.gunaTextBox7.Name = "gunaTextBox7";
            this.gunaTextBox7.PasswordChar = '\0';
            this.gunaTextBox7.SelectedText = "";
            this.gunaTextBox7.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox7.TabIndex = 15;
            this.gunaTextBox7.TextChanged += new System.EventHandler(this.gunaTextBox7_TextChanged);
            // 
            // gunaTextBox8
            // 
            this.gunaTextBox8.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox8.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox8.BorderSize = 0;
            this.gunaTextBox8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox8.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox8.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox8.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox8.Location = new System.Drawing.Point(61, 145);
            this.gunaTextBox8.Name = "gunaTextBox8";
            this.gunaTextBox8.PasswordChar = '\0';
            this.gunaTextBox8.SelectedText = "";
            this.gunaTextBox8.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox8.TabIndex = 14;
            this.gunaTextBox8.TextChanged += new System.EventHandler(this.gunaTextBox8_TextChanged);
            // 
            // gunaTextBox9
            // 
            this.gunaTextBox9.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox9.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox9.BorderSize = 0;
            this.gunaTextBox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox9.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox9.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox9.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox9.Location = new System.Drawing.Point(545, 176);
            this.gunaTextBox9.Name = "gunaTextBox9";
            this.gunaTextBox9.PasswordChar = '\0';
            this.gunaTextBox9.SelectedText = "";
            this.gunaTextBox9.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox9.TabIndex = 21;
            this.gunaTextBox9.Text = "0";
            // 
            // gunaTextBox10
            // 
            this.gunaTextBox10.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox10.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox10.BorderSize = 0;
            this.gunaTextBox10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox10.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox10.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox10.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox10.Location = new System.Drawing.Point(383, 176);
            this.gunaTextBox10.Name = "gunaTextBox10";
            this.gunaTextBox10.PasswordChar = '\0';
            this.gunaTextBox10.SelectedText = "";
            this.gunaTextBox10.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox10.TabIndex = 20;
            this.gunaTextBox10.TextChanged += new System.EventHandler(this.gunaTextBox10_TextChanged);
            // 
            // gunaTextBox11
            // 
            this.gunaTextBox11.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox11.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox11.BorderSize = 0;
            this.gunaTextBox11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox11.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox11.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox11.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox11.Location = new System.Drawing.Point(222, 176);
            this.gunaTextBox11.Margin = new System.Windows.Forms.Padding(2);
            this.gunaTextBox11.Name = "gunaTextBox11";
            this.gunaTextBox11.PasswordChar = '\0';
            this.gunaTextBox11.SelectedText = "";
            this.gunaTextBox11.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox11.TabIndex = 19;
            // 
            // gunaTextBox12
            // 
            this.gunaTextBox12.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox12.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox12.BorderSize = 0;
            this.gunaTextBox12.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox12.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox12.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox12.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox12.Location = new System.Drawing.Point(61, 176);
            this.gunaTextBox12.Name = "gunaTextBox12";
            this.gunaTextBox12.PasswordChar = '\0';
            this.gunaTextBox12.SelectedText = "";
            this.gunaTextBox12.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox12.TabIndex = 18;
            this.gunaTextBox12.TextChanged += new System.EventHandler(this.gunaTextBox12_TextChanged);
            // 
            // gunaTextBox13
            // 
            this.gunaTextBox13.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox13.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox13.BorderSize = 0;
            this.gunaTextBox13.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox13.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox13.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox13.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox13.Location = new System.Drawing.Point(545, 207);
            this.gunaTextBox13.Name = "gunaTextBox13";
            this.gunaTextBox13.PasswordChar = '\0';
            this.gunaTextBox13.SelectedText = "";
            this.gunaTextBox13.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox13.TabIndex = 25;
            this.gunaTextBox13.Text = "0";
            // 
            // gunaTextBox14
            // 
            this.gunaTextBox14.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox14.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox14.BorderSize = 0;
            this.gunaTextBox14.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox14.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox14.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox14.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox14.Location = new System.Drawing.Point(383, 207);
            this.gunaTextBox14.Name = "gunaTextBox14";
            this.gunaTextBox14.PasswordChar = '\0';
            this.gunaTextBox14.SelectedText = "";
            this.gunaTextBox14.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox14.TabIndex = 24;
            this.gunaTextBox14.TextChanged += new System.EventHandler(this.gunaTextBox14_TextChanged);
            // 
            // gunaTextBox15
            // 
            this.gunaTextBox15.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox15.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox15.BorderSize = 0;
            this.gunaTextBox15.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox15.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox15.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox15.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox15.Location = new System.Drawing.Point(222, 207);
            this.gunaTextBox15.Margin = new System.Windows.Forms.Padding(2);
            this.gunaTextBox15.Name = "gunaTextBox15";
            this.gunaTextBox15.PasswordChar = '\0';
            this.gunaTextBox15.SelectedText = "";
            this.gunaTextBox15.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox15.TabIndex = 23;
            // 
            // gunaTextBox16
            // 
            this.gunaTextBox16.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox16.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox16.BorderSize = 0;
            this.gunaTextBox16.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox16.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox16.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox16.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox16.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox16.Location = new System.Drawing.Point(61, 207);
            this.gunaTextBox16.Name = "gunaTextBox16";
            this.gunaTextBox16.PasswordChar = '\0';
            this.gunaTextBox16.SelectedText = "";
            this.gunaTextBox16.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox16.TabIndex = 22;
            this.gunaTextBox16.TextChanged += new System.EventHandler(this.gunaTextBox16_TextChanged);
            // 
            // gunaTextBox17
            // 
            this.gunaTextBox17.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox17.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox17.BorderSize = 0;
            this.gunaTextBox17.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox17.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox17.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox17.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox17.Location = new System.Drawing.Point(545, 238);
            this.gunaTextBox17.Name = "gunaTextBox17";
            this.gunaTextBox17.PasswordChar = '\0';
            this.gunaTextBox17.SelectedText = "";
            this.gunaTextBox17.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox17.TabIndex = 29;
            this.gunaTextBox17.Text = "0";
            // 
            // gunaTextBox18
            // 
            this.gunaTextBox18.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox18.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox18.BorderSize = 0;
            this.gunaTextBox18.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox18.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox18.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox18.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox18.Location = new System.Drawing.Point(383, 238);
            this.gunaTextBox18.Name = "gunaTextBox18";
            this.gunaTextBox18.PasswordChar = '\0';
            this.gunaTextBox18.SelectedText = "";
            this.gunaTextBox18.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox18.TabIndex = 28;
            this.gunaTextBox18.TextChanged += new System.EventHandler(this.gunaTextBox18_TextChanged);
            // 
            // gunaTextBox19
            // 
            this.gunaTextBox19.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox19.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox19.BorderSize = 0;
            this.gunaTextBox19.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox19.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox19.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox19.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox19.Location = new System.Drawing.Point(222, 238);
            this.gunaTextBox19.Margin = new System.Windows.Forms.Padding(2);
            this.gunaTextBox19.Name = "gunaTextBox19";
            this.gunaTextBox19.PasswordChar = '\0';
            this.gunaTextBox19.SelectedText = "";
            this.gunaTextBox19.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox19.TabIndex = 27;
            // 
            // gunaTextBox20
            // 
            this.gunaTextBox20.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox20.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox20.BorderSize = 0;
            this.gunaTextBox20.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox20.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox20.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox20.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox20.Location = new System.Drawing.Point(61, 238);
            this.gunaTextBox20.Name = "gunaTextBox20";
            this.gunaTextBox20.PasswordChar = '\0';
            this.gunaTextBox20.SelectedText = "";
            this.gunaTextBox20.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox20.TabIndex = 26;
            this.gunaTextBox20.TextChanged += new System.EventHandler(this.gunaTextBox20_TextChanged);
            // 
            // gunaTextBox21
            // 
            this.gunaTextBox21.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox21.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox21.BorderSize = 0;
            this.gunaTextBox21.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox21.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox21.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox21.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox21.Location = new System.Drawing.Point(545, 269);
            this.gunaTextBox21.Name = "gunaTextBox21";
            this.gunaTextBox21.PasswordChar = '\0';
            this.gunaTextBox21.SelectedText = "";
            this.gunaTextBox21.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox21.TabIndex = 33;
            this.gunaTextBox21.Text = "0";
            this.gunaTextBox21.TextChanged += new System.EventHandler(this.gunaTextBox21_TextChanged);
            // 
            // gunaTextBox22
            // 
            this.gunaTextBox22.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox22.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox22.BorderSize = 0;
            this.gunaTextBox22.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox22.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox22.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox22.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox22.Location = new System.Drawing.Point(383, 269);
            this.gunaTextBox22.Name = "gunaTextBox22";
            this.gunaTextBox22.PasswordChar = '\0';
            this.gunaTextBox22.SelectedText = "";
            this.gunaTextBox22.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox22.TabIndex = 32;
            this.gunaTextBox22.TextChanged += new System.EventHandler(this.gunaTextBox22_TextChanged);
            // 
            // gunaTextBox23
            // 
            this.gunaTextBox23.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox23.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox23.BorderSize = 0;
            this.gunaTextBox23.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox23.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox23.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox23.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox23.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox23.Location = new System.Drawing.Point(222, 269);
            this.gunaTextBox23.Margin = new System.Windows.Forms.Padding(2);
            this.gunaTextBox23.Name = "gunaTextBox23";
            this.gunaTextBox23.PasswordChar = '\0';
            this.gunaTextBox23.SelectedText = "";
            this.gunaTextBox23.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox23.TabIndex = 31;
            // 
            // gunaTextBox24
            // 
            this.gunaTextBox24.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox24.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox24.BorderSize = 0;
            this.gunaTextBox24.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox24.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox24.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox24.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox24.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox24.Location = new System.Drawing.Point(61, 269);
            this.gunaTextBox24.Name = "gunaTextBox24";
            this.gunaTextBox24.PasswordChar = '\0';
            this.gunaTextBox24.SelectedText = "";
            this.gunaTextBox24.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox24.TabIndex = 30;
            this.gunaTextBox24.TextChanged += new System.EventHandler(this.gunaTextBox24_TextChanged);
            // 
            // gunaTextBox33
            // 
            this.gunaTextBox33.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox33.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox33.BorderSize = 0;
            this.gunaTextBox33.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox33.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox33.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox33.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox33.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox33.Location = new System.Drawing.Point(545, 331);
            this.gunaTextBox33.Name = "gunaTextBox33";
            this.gunaTextBox33.PasswordChar = '\0';
            this.gunaTextBox33.SelectedText = "";
            this.gunaTextBox33.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox33.TabIndex = 41;
            this.gunaTextBox33.Text = "0";
            this.gunaTextBox33.TextChanged += new System.EventHandler(this.gunaTextBox33_TextChanged);
            // 
            // gunaTextBox34
            // 
            this.gunaTextBox34.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox34.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox34.BorderSize = 0;
            this.gunaTextBox34.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox34.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox34.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox34.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox34.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox34.Location = new System.Drawing.Point(383, 331);
            this.gunaTextBox34.Name = "gunaTextBox34";
            this.gunaTextBox34.PasswordChar = '\0';
            this.gunaTextBox34.SelectedText = "";
            this.gunaTextBox34.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox34.TabIndex = 40;
            this.gunaTextBox34.TextChanged += new System.EventHandler(this.gunaTextBox34_TextChanged);
            // 
            // gunaTextBox35
            // 
            this.gunaTextBox35.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox35.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox35.BorderSize = 0;
            this.gunaTextBox35.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox35.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox35.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox35.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox35.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox35.Location = new System.Drawing.Point(222, 331);
            this.gunaTextBox35.Margin = new System.Windows.Forms.Padding(2);
            this.gunaTextBox35.Name = "gunaTextBox35";
            this.gunaTextBox35.PasswordChar = '\0';
            this.gunaTextBox35.SelectedText = "";
            this.gunaTextBox35.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox35.TabIndex = 39;
            // 
            // gunaTextBox36
            // 
            this.gunaTextBox36.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox36.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox36.BorderSize = 0;
            this.gunaTextBox36.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox36.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox36.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox36.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox36.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox36.Location = new System.Drawing.Point(61, 331);
            this.gunaTextBox36.Name = "gunaTextBox36";
            this.gunaTextBox36.PasswordChar = '\0';
            this.gunaTextBox36.SelectedText = "";
            this.gunaTextBox36.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox36.TabIndex = 38;
            this.gunaTextBox36.TextChanged += new System.EventHandler(this.gunaTextBox36_TextChanged);
            // 
            // gunaTextBox37
            // 
            this.gunaTextBox37.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox37.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox37.BorderSize = 0;
            this.gunaTextBox37.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox37.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox37.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox37.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox37.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox37.Location = new System.Drawing.Point(545, 300);
            this.gunaTextBox37.Name = "gunaTextBox37";
            this.gunaTextBox37.PasswordChar = '\0';
            this.gunaTextBox37.SelectedText = "";
            this.gunaTextBox37.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox37.TabIndex = 37;
            this.gunaTextBox37.Text = "0";
            // 
            // gunaTextBox38
            // 
            this.gunaTextBox38.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox38.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox38.BorderSize = 0;
            this.gunaTextBox38.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox38.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox38.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox38.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox38.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox38.Location = new System.Drawing.Point(383, 300);
            this.gunaTextBox38.Name = "gunaTextBox38";
            this.gunaTextBox38.PasswordChar = '\0';
            this.gunaTextBox38.SelectedText = "";
            this.gunaTextBox38.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox38.TabIndex = 36;
            this.gunaTextBox38.TextChanged += new System.EventHandler(this.gunaTextBox38_TextChanged);
            // 
            // gunaTextBox39
            // 
            this.gunaTextBox39.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox39.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox39.BorderSize = 0;
            this.gunaTextBox39.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox39.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox39.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox39.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox39.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox39.Location = new System.Drawing.Point(222, 300);
            this.gunaTextBox39.Margin = new System.Windows.Forms.Padding(2);
            this.gunaTextBox39.Name = "gunaTextBox39";
            this.gunaTextBox39.PasswordChar = '\0';
            this.gunaTextBox39.SelectedText = "";
            this.gunaTextBox39.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox39.TabIndex = 35;
            // 
            // gunaTextBox40
            // 
            this.gunaTextBox40.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox40.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox40.BorderSize = 0;
            this.gunaTextBox40.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox40.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox40.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox40.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox40.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox40.Location = new System.Drawing.Point(61, 300);
            this.gunaTextBox40.Name = "gunaTextBox40";
            this.gunaTextBox40.PasswordChar = '\0';
            this.gunaTextBox40.SelectedText = "";
            this.gunaTextBox40.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox40.TabIndex = 34;
            this.gunaTextBox40.TextChanged += new System.EventHandler(this.gunaTextBox40_TextChanged);
            // 
            // gunaTextBox25
            // 
            this.gunaTextBox25.BaseColor = System.Drawing.Color.White;
            this.gunaTextBox25.BorderColor = System.Drawing.Color.Silver;
            this.gunaTextBox25.BorderSize = 0;
            this.gunaTextBox25.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaTextBox25.FocusedBaseColor = System.Drawing.Color.White;
            this.gunaTextBox25.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaTextBox25.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.gunaTextBox25.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaTextBox25.Location = new System.Drawing.Point(546, 378);
            this.gunaTextBox25.Name = "gunaTextBox25";
            this.gunaTextBox25.PasswordChar = '\0';
            this.gunaTextBox25.SelectedText = "";
            this.gunaTextBox25.Size = new System.Drawing.Size(160, 30);
            this.gunaTextBox25.TabIndex = 42;
            this.gunaTextBox25.Text = "00.00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(76, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 43;
            this.label5.Text = "Name";
            // 
            // gunaLineTextBox1
            // 
            this.gunaLineTextBox1.BackColor = System.Drawing.Color.White;
            this.gunaLineTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gunaLineTextBox1.FocusedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(134)))), ((int)(((byte)(5)))));
            this.gunaLineTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLineTextBox1.LineColor = System.Drawing.Color.Gainsboro;
            this.gunaLineTextBox1.LineSize = 1;
            this.gunaLineTextBox1.Location = new System.Drawing.Point(128, 46);
            this.gunaLineTextBox1.Name = "gunaLineTextBox1";
            this.gunaLineTextBox1.PasswordChar = '\0';
            this.gunaLineTextBox1.SelectedText = "";
            this.gunaLineTextBox1.Size = new System.Drawing.Size(235, 26);
            this.gunaLineTextBox1.TabIndex = 45;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(34)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gunaLineTextBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.gunaTextBox25);
            this.Controls.Add(this.gunaTextBox33);
            this.Controls.Add(this.gunaTextBox34);
            this.Controls.Add(this.gunaTextBox35);
            this.Controls.Add(this.gunaTextBox36);
            this.Controls.Add(this.gunaTextBox37);
            this.Controls.Add(this.gunaTextBox38);
            this.Controls.Add(this.gunaTextBox39);
            this.Controls.Add(this.gunaTextBox40);
            this.Controls.Add(this.gunaTextBox21);
            this.Controls.Add(this.gunaTextBox22);
            this.Controls.Add(this.gunaTextBox23);
            this.Controls.Add(this.gunaTextBox24);
            this.Controls.Add(this.gunaTextBox17);
            this.Controls.Add(this.gunaTextBox18);
            this.Controls.Add(this.gunaTextBox19);
            this.Controls.Add(this.gunaTextBox20);
            this.Controls.Add(this.gunaTextBox13);
            this.Controls.Add(this.gunaTextBox14);
            this.Controls.Add(this.gunaTextBox15);
            this.Controls.Add(this.gunaTextBox16);
            this.Controls.Add(this.gunaTextBox9);
            this.Controls.Add(this.gunaTextBox10);
            this.Controls.Add(this.gunaTextBox11);
            this.Controls.Add(this.gunaTextBox12);
            this.Controls.Add(this.gunaTextBox5);
            this.Controls.Add(this.gunaTextBox6);
            this.Controls.Add(this.gunaTextBox7);
            this.Controls.Add(this.gunaTextBox8);
            this.Controls.Add(this.gunaTextBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gunaTextBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gunaTextBox2);
            this.Controls.Add(this.gunaTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gunaGradientButton2);
            this.Controls.Add(this.gunaGradientButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaGradientButton gunaGradientButton1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private Guna.UI.WinForms.GunaGradientButton gunaGradientButton2;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox1;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox3;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox4;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox5;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox6;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox7;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox8;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox9;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox10;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox11;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox12;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox13;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox14;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox15;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox16;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox17;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox18;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox19;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox20;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox21;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox22;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox23;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox24;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox33;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox34;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox35;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox36;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox37;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox38;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox39;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox40;
        private Guna.UI.WinForms.GunaTextBox gunaTextBox25;
        private System.Windows.Forms.Label label5;
        private Guna.UI.WinForms.GunaLineTextBox gunaLineTextBox1;
    }
}