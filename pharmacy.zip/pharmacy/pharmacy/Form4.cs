﻿using Guna.UI.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmacy
{
    public partial class Form4 : Form
    {
        string connectionString = "Data Source=(localdb)\\Local;Initial Catalog=Pharmacy;Integrated Security=True";
        public Form4()
        {
            InitializeComponent();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(gunaLineTextBox1.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(120, 10));
            e.Graphics.DrawString(gunaTextBox1.Text,new Font("Arial",20,FontStyle.Bold),Brushes.Black,new Point(110,120));
            e.Graphics.DrawString(gunaTextBox2.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(260, 120));
            e.Graphics.DrawString(gunaTextBox3.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(410, 120));
            e.Graphics.DrawString(gunaTextBox4.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 120));
            if (gunaTextBox8.Text!=null)
            {
                e.Graphics.DrawString(gunaTextBox8.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(110, 160));
                e.Graphics.DrawString(gunaTextBox7.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(260, 160));
                e.Graphics.DrawString(gunaTextBox6.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(410, 160));
                e.Graphics.DrawString(gunaTextBox5.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 160));
            }
            if (gunaTextBox12.Text != null)
            {
                e.Graphics.DrawString(gunaTextBox12.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(110, 220));
                e.Graphics.DrawString(gunaTextBox11.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(260, 220));
                e.Graphics.DrawString(gunaTextBox10.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(410, 220));
                e.Graphics.DrawString(gunaTextBox9.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 220));
            }
            if (gunaTextBox16.Text != null)
            {
                e.Graphics.DrawString(gunaTextBox12.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(110, 320));
                e.Graphics.DrawString(gunaTextBox11.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(260, 320));
                e.Graphics.DrawString(gunaTextBox10.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(410, 320));
                e.Graphics.DrawString(gunaTextBox9.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 320));
            }
            if (gunaTextBox20.Text != null)
            {
                e.Graphics.DrawString(gunaTextBox20.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(110, 420));
                e.Graphics.DrawString(gunaTextBox19.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(260, 420));
                e.Graphics.DrawString(gunaTextBox18.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(410, 420));
                e.Graphics.DrawString(gunaTextBox17.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 420));
            }
            if (gunaTextBox24.Text != null)
            {
                e.Graphics.DrawString(gunaTextBox24.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(110, 520));
                e.Graphics.DrawString(gunaTextBox23.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(260, 520));
                e.Graphics.DrawString(gunaTextBox22.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(410, 520));
                e.Graphics.DrawString(gunaTextBox21.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 520));
            }
            if (gunaTextBox36.Text != null)
            {
                e.Graphics.DrawString(gunaTextBox36.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(110, 420));
                e.Graphics.DrawString(gunaTextBox35.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(260, 420));
                e.Graphics.DrawString(gunaTextBox34.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(410, 420));
                e.Graphics.DrawString(gunaTextBox33.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 420));
            }
            if (gunaTextBox40.Text != null)
            {
                e.Graphics.DrawString(gunaTextBox40.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(110, 520));
                e.Graphics.DrawString(gunaTextBox39.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(260, 520));
                e.Graphics.DrawString(gunaTextBox38.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(410, 520));
                e.Graphics.DrawString(gunaTextBox37.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 520));
            }
            e.Graphics.DrawString(gunaTextBox25.Text, new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(560, 720));
        }

        Bitmap bmp;
        private void gunaGradientButton1_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
        public float m;
        private void gunaGradientButton2_Click(object sender, EventArgs e)
        {
            m=float.Parse(gunaTextBox4.Text) +float.Parse( gunaTextBox5.Text) + float.Parse(gunaTextBox9.Text) + float.Parse(gunaTextBox13.Text) + float.Parse(gunaTextBox17.Text + float.Parse(gunaTextBox21.Text)) + float.Parse(gunaTextBox33.Text) + float.Parse(gunaTextBox37.Text);
            gunaTextBox25.Text = m.ToString();
        }
        
        private void gunaTextBox1_TextChanged(object sender, EventArgs e)      
        {
            try { 
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scmd = new SqlCommand("select medName from medcine where medID=" + gunaTextBox1.Text, scon);
                SqlDataReader sr=scmd.ExecuteReader();
                while (sr.Read())
                {
                    gunaTextBox2.Text = sr.GetString(0).ToString();
                }
            }}
            catch(Exception ex) {
                gunaTextBox2.Text = "Not Found";
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void gunaTextBox3_TextChanged(object sender, EventArgs e)
        {
            int quantity;
            float price;
                using (SqlConnection scon = new SqlConnection(connectionString))
                {
                    scon.Open();
                    SqlCommand scmd = new SqlCommand("select quantity,price from medcine where medID="+ gunaTextBox1.Text, scon);
                    SqlDataReader sr = scmd.ExecuteReader();
                    while (sr.Read())
                    {
                        quantity = int.Parse(sr.GetValue(0).ToString());
                    try
                    {
                        if (quantity >= int.Parse(gunaTextBox3.Text))
                        {
                            gunaTextBox4.Text = (float.Parse(gunaTextBox3.Text.ToString()) * float.Parse(sr.GetValue(1).ToString())).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Medicine is OUT OF STOCK");
                        }
                    }
                    catch {
                        gunaTextBox4.Text="";
                    }
                    }
                }
            }

        private void gunaTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaTextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaTextBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaTextBox8_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection scon = new SqlConnection(connectionString))
                {
                    scon.Open();
                    SqlCommand scmd = new SqlCommand("select medName from medcine where medID=" + gunaTextBox8.Text, scon);
                    SqlDataReader sr = scmd.ExecuteReader();
                    while (sr.Read())
                    {
                        gunaTextBox7.Text = sr.GetString(0).ToString();
                    }
                }
            }
            catch
            {
                gunaTextBox7.Text = "Not Found";
            }
        }

        private void gunaTextBox6_TextChanged(object sender, EventArgs e)
        {
            int quantity1;
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scmd = new SqlCommand("select quantity,price from medcine where medID=" + gunaTextBox8.Text, scon);
                SqlDataReader sr = scmd.ExecuteReader();
                while (sr.Read())
                {
                    quantity1 = int.Parse(sr.GetValue(0).ToString());
                    try
                    {
                        if (quantity1 >= int.Parse(gunaTextBox6.Text))
                        {
                            gunaTextBox5.Text = (float.Parse(gunaTextBox6.Text.ToString()) * float.Parse(sr.GetValue(1).ToString())).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Medicine is OUT OF STOCK");
                        }
                    }
                    catch
                    {
                        gunaTextBox5.Text = "";
                    }
                }
            }
        }

        private void gunaTextBox12_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection scon = new SqlConnection(connectionString))
                {
                    scon.Open();
                    SqlCommand scmd = new SqlCommand("select medName from medcine where medID=" + gunaTextBox12.Text, scon);
                    SqlDataReader sr = scmd.ExecuteReader();
                    while (sr.Read())
                    {
                        gunaTextBox11.Text = sr.GetString(0).ToString();
                    }
                }
            }
            catch
            {
                gunaTextBox11.Text = "Not Found";
            }
        }

        private void gunaTextBox10_TextChanged(object sender, EventArgs e)
        {
            int quantity;
            float price;
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scmd = new SqlCommand("select quantity,price from medcine where medID=" + gunaTextBox12.Text, scon);
                SqlDataReader sr = scmd.ExecuteReader();
                while (sr.Read())
                {
                    quantity = int.Parse(sr.GetValue(0).ToString());
                    try
                    {
                        if (quantity >= int.Parse(gunaTextBox10.Text))
                        {
                            gunaTextBox9.Text = (float.Parse(gunaTextBox3.Text.ToString()) * float.Parse(sr.GetValue(1).ToString())).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Medicine is OUT OF STOCK");
                        }
                    }
                    catch
                    {
                        gunaTextBox9.Text = "";
                    }
                }
            }
        }

        private void gunaTextBox16_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection scon = new SqlConnection(connectionString))
                {
                    scon.Open();
                    SqlCommand scmd = new SqlCommand("select medName from medcine where medID=" + gunaTextBox16.Text, scon);
                    SqlDataReader sr = scmd.ExecuteReader();
                    while (sr.Read())
                    {
                        gunaTextBox15.Text = sr.GetString(0).ToString();
                    }
                }
            }
            catch
            {
                gunaTextBox15.Text = "Not Found";
            }
        }

        private void gunaTextBox14_TextChanged(object sender, EventArgs e)
        {
            int quantity;
            float price;
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scmd = new SqlCommand("select quantity,price from medcine where medID=" + gunaTextBox16.Text, scon);
                SqlDataReader sr = scmd.ExecuteReader();
                while (sr.Read())
                {
                    quantity = int.Parse(sr.GetValue(0).ToString());
                    try
                    {
                        if (quantity >= int.Parse(gunaTextBox14.Text))
                        {
                            gunaTextBox13.Text = (float.Parse(gunaTextBox14.Text.ToString()) * float.Parse(sr.GetValue(1).ToString())).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Medicine is OUT OF STOCK");
                        }
                    }
                    catch
                    {
                        gunaTextBox13.Text = "";
                    }
                }
            }
        }

        private void gunaTextBox20_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection scon = new SqlConnection(connectionString))
                {
                    scon.Open();
                    SqlCommand scmd = new SqlCommand("select medName from medcine where medID=" + gunaTextBox20.Text, scon);
                    SqlDataReader sr = scmd.ExecuteReader();
                    while (sr.Read())
                    {
                        gunaTextBox19.Text = sr.GetString(0).ToString();
                    }
                }
            }
            catch
            {
                gunaTextBox19.Text = "Not Found";
            }
        }

        private void gunaTextBox18_TextChanged(object sender, EventArgs e)
        {
            int quantity;
            float price;
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scmd = new SqlCommand("select quantity,price from medcine where medID=" + gunaTextBox20.Text, scon);
                SqlDataReader sr = scmd.ExecuteReader();
                while (sr.Read())
                {
                    quantity = int.Parse(sr.GetValue(0).ToString());
                    try
                    {
                        if (quantity >= int.Parse(gunaTextBox18.Text))
                        {
                            gunaTextBox17.Text = (float.Parse(gunaTextBox18.Text.ToString()) * float.Parse(sr.GetValue(1).ToString())).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Medicine is OUT OF STOCK");
                        }
                    }
                    catch
                    {
                        gunaTextBox17.Text = "";
                    }
                }
            }
        }

        private void gunaTextBox21_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaTextBox24_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection scon = new SqlConnection(connectionString))
                {
                    scon.Open();
                    SqlCommand scmd = new SqlCommand("select medName from medcine where medID=" + gunaTextBox24.Text, scon);
                    SqlDataReader sr = scmd.ExecuteReader();
                    while (sr.Read())
                    {
                        gunaTextBox23.Text = sr.GetString(0).ToString();
                    }
                }
            }
            catch
            {
                gunaTextBox23.Text = "Not Found";
            }
        }

        private void gunaTextBox22_TextChanged(object sender, EventArgs e)
        {
            int quantity;
            float price;
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scmd = new SqlCommand("select quantity,price from medcine where medID=" + gunaTextBox24.Text, scon);
                SqlDataReader sr = scmd.ExecuteReader();
                while (sr.Read())
                {
                    quantity = int.Parse(sr.GetValue(0).ToString());
                    try
                    {
                        if (quantity >= int.Parse(gunaTextBox22.Text))
                        {
                            gunaTextBox21.Text = (float.Parse(gunaTextBox22.Text.ToString()) * float.Parse(sr.GetValue(1).ToString())).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Medicine is OUT OF STOCK");
                        }
                    }
                    catch
                    {
                        gunaTextBox21.Text = "";
                    }
                }
            }
        }

        private void gunaTextBox40_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection scon = new SqlConnection(connectionString))
                {
                    scon.Open();
                    SqlCommand scmd = new SqlCommand("select medName from medcine where medID=" + gunaTextBox40.Text, scon);
                    SqlDataReader sr = scmd.ExecuteReader();
                    while (sr.Read())
                    {
                        gunaTextBox39.Text = sr.GetString(0).ToString();
                    }
                }
            }
            catch
            {
                gunaTextBox39.Text = "Not Found";
            }
        }

        private void gunaTextBox36_TextChanged(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection scon = new SqlConnection(connectionString))
                {
                    scon.Open();
                    SqlCommand scmd = new SqlCommand("select medName from medcine where medID=" + gunaTextBox36.Text, scon);
                    SqlDataReader sr = scmd.ExecuteReader();
                    while (sr.Read())
                    {
                        gunaTextBox35.Text = sr.GetString(0).ToString();
                    }
                }
            }
            catch
            {
                gunaTextBox35.Text = "Not Found";
            }
        }

        private void gunaTextBox38_TextChanged(object sender, EventArgs e)
        {
            int quantity;
            float price;
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scmd = new SqlCommand("select quantity,price from medcine where medID=" + gunaTextBox40.Text, scon);
                SqlDataReader sr = scmd.ExecuteReader();
                while (sr.Read())
                {
                    quantity = int.Parse(sr.GetValue(0).ToString());
                    try
                    {
                        if (quantity >= int.Parse(gunaTextBox38.Text))
                        {
                            gunaTextBox37.Text = (float.Parse(gunaTextBox38.Text.ToString()) * float.Parse(sr.GetValue(1).ToString())).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Medicine is OUT OF STOCK");
                        }
                    }
                    catch
                    {
                        gunaTextBox37.Text = "";
                    }
                }
            }
        }

        private void gunaTextBox34_TextChanged(object sender, EventArgs e)
        {
            int quantity;
            float price;
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();
                SqlCommand scmd = new SqlCommand("select quantity,price from medcine where medID=" + gunaTextBox36.Text, scon);
                SqlDataReader sr = scmd.ExecuteReader();
                while (sr.Read())
                {
                    quantity = int.Parse(sr.GetValue(0).ToString());
                    try
                    {
                        if (quantity >= int.Parse(gunaTextBox34.Text))
                        {
                            gunaTextBox33.Text = (float.Parse(gunaTextBox34.Text.ToString()) * float.Parse(sr.GetValue(1).ToString())).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Medicine is OUT OF STOCK");
                        }
                    }
                    catch
                    {
                        gunaTextBox33.Text = "";
                    }
                }
            }
        }

        private void gunaTextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaTextBox33_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void gunaTextBox26_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

