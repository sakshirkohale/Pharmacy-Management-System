﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pharmacy
{
    public partial class Form5 : Form
    {
        string connectionString = "Data Source=(localdb)\\Local;Initial Catalog=Pharmacy;Integrated Security=True";
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            timer1.Start();
            Showmed();
        }
        public void Showmed()
        {
            using (SqlConnection scon=new SqlConnection(connectionString))
            {
                scon.Open();
                SqlDataAdapter sqlCommand = new SqlDataAdapter("select * from medcine where quantity<=100", scon);
                DataTable dt1 = new DataTable();
                sqlCommand.Fill(dt1);
                gunaDataGridView1.DataSource= dt1;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Showmed();
        }
        Bitmap bmp;
        private void gunaGradientButton1_Click(object sender, EventArgs e)
        {
            printDialog1.Document = printDocument1;
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.gunaDataGridView1.Width, this.gunaDataGridView1.Height);
            gunaDataGridView1.DrawToBitmap(bm, new Rectangle(0, 0, this.gunaDataGridView1.Width, this.gunaDataGridView1.Height));
            e.Graphics.DrawImage(bm, 0, 0);
            printDialog1.ShowDialog(); 
        }
    }
}
